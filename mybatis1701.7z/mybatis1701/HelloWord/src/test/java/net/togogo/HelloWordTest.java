package net.togogo;

import net.togogo.bean.User;
import net.togogo.dao.UserMaper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HelloWordTest {

    private SqlSessionFactory sqlSessionFactory;

    //读取mybatis-config.xml配置文件 @Before在某某执行之前先执行
    @Before
    public void initConf(){

        InputStream is = null;
        try {
            is = Resources.getResourceAsStream("mybatis-config.xml");
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //获取SqlSession
    @Test
    public void getSqlSession(){
        SqlSession sqlsession = sqlSessionFactory.openSession();
        System.out.println("获取到的session是：" + sqlsession);
    }

    //通过sqlsession操作数据库
    @Test
    public void insert(){
        //1:获取sqlsession
        SqlSession sqlsession = sqlSessionFactory.openSession();
        //2:创建插入的user对象
        User user = new User("钱太多","654321","HTML");
        //3:获取UserMapper代理对象
        UserMaper mapper = sqlsession.getMapper(UserMaper.class);
        System.out.println("mapper = " + mapper.getClass().getName());
        //4:通过mapper执行insert方法 返回插入对象的数量
        int result = mapper.insert(user);
        System.out.println("操作成功，插入：" + result + "条数据");
        System.out.println(user.getId());
        //5：事务管理
        sqlsession.commit();
        sqlsession.close();
    }

    @Test
    public void selectById(){
        SqlSession sqlsession = sqlSessionFactory.openSession();
        UserMaper mapper = sqlsession.getMapper(UserMaper.class);
        User id = mapper.selectById(1);
        System.out.println("id = " + id);
        sqlsession.close();
    }

    @Test
    public void selectByName(){
        SqlSession sqlsession = sqlSessionFactory.openSession();
        UserMaper mapper = sqlsession.getMapper(UserMaper.class);
        List<User> users = mapper.selectByName("钱多多");
        users.stream().forEach(System.out::println);
        sqlsession.close();
    }

    @Test
    public void selectByNameAndPassword(){
        SqlSession sqlsession = sqlSessionFactory.openSession();
        UserMaper mapper = sqlsession.getMapper(UserMaper.class);
        Map<String,Object> map = new HashMap<>();
        map.put("name","钱多多");
        map.put("password","123456");
        List<User> users = mapper.selectByNameAndPassword(map);
        users.stream().forEach(System.out::println);
        sqlsession.close();
    }
    @Test
    public void selectByNames(){
        SqlSession sqlsession = sqlSessionFactory.openSession();
        UserMaper mapper = sqlsession.getMapper(UserMaper.class);
        List<String> names = new ArrayList<>();
        names.add("钱多多");
        names.add("钱好多");
        List<User> users = mapper.selectByNames(names);
        users.stream().forEach(System.out::println);
        sqlsession.close();
    }

    @Test
    public void deleteById(){
        SqlSession sqlsession = sqlSessionFactory.openSession();
        UserMaper mapper = sqlsession.getMapper(UserMaper.class);
        mapper.deleteById(3);
        sqlsession.commit();
        sqlsession.close();
    }

    @Test
    public void updateById(){
        SqlSession sqlsession = sqlSessionFactory.openSession();
        UserMaper mapper = sqlsession.getMapper(UserMaper.class);
        User user = new User("钱巨多","1236987","有钱");
        user.setId(4);
        mapper.updateById(user);
        sqlsession.commit();
        sqlsession.close();
    }

}
