package net.togogo.dao;

import net.togogo.bean.User;

import java.util.List;
import java.util.Map;

public interface UserMaper {

    //insert
    int insert (User user);

    //selectById
    User selectById(int id);

    //selectByName
    List<User> selectByName(String name);

    //selectByNameAndPassword
    List<User> selectByNameAndPassword(Map<String,Object> map);

    //批量查询 selectByNames
    List<User> selectByNames(List<String> names);

    //deleteById
    void deleteById (int id);

    //批量删除  用户名和密码删除

    //updateById
    void updateById (User user);


}
